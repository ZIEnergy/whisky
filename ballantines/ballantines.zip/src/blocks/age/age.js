$('.age__button--yes').click(function(e) {
  e.preventDefault();
  $('.age').fadeOut('fast');
});