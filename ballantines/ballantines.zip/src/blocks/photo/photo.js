$('.fancybox').fancybox({
  
});