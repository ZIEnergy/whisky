$('.menu__button').click(function() {
  
});