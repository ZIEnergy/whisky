$('.close').click(function(e) {
  e.preventDefault();
  parent.$.fancybox.close();
})