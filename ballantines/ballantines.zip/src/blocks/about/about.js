$('.about__slider').slick({
    arrows: true,
    dots: true,
    vertical: true
});